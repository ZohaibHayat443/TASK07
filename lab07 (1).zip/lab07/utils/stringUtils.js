// utils/stringUtils.js - text helpers (Task 1)

// Every word starts with a capital letter, the rest is lowercase
const capitalizeWords = (text) =>
  text
    .trim()
    .split(/\s+/)
    .filter(Boolean)
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(" ");

// Lowercase, extra spaces removed, spaces replaced by hyphens
const slugify = (text) =>
  text.trim().toLowerCase().split(/\s+/).filter(Boolean).join("-");

const countWords = (text) =>
  text.trim() === "" ? 0 : text.trim().split(/\s+/).length;

module.exports = { capitalizeWords, slugify, countWords };

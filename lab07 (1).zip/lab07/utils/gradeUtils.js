// utils/gradeUtils.js - grading helpers (Task 1)

// CGPA status (same table as Lab 06) written with the ternary operator
const getStatus = (cgpa) =>
  cgpa >= 3.0 ? "Excellent" :
  cgpa >= 2.5 ? "Good" :
  cgpa >= 2.0 ? "Satisfactory" :
  "Academic Warning";

// A: 85+, B: 70-84, C: 55-69, D: 40-54, F: below 40
const letterGrade = (marks) =>
  marks >= 85 ? "A" :
  marks >= 70 ? "B" :
  marks >= 55 ? "C" :
  marks >= 40 ? "D" :
  "F";

// courses = [{ points, credits }, ...]  ->  credit-weighted average
const calculateGPA = (courses) => {
  const totalCredits = courses.reduce((sum, c) => sum + c.credits, 0);
  if (totalCredits === 0) return 0;
  const totalPoints = courses.reduce((sum, c) => sum + c.points * c.credits, 0);
  return totalPoints / totalCredits;
};

module.exports = { getStatus, letterGrade, calculateGPA };

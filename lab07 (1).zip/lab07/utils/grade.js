// utils/grade.js - CGPA status (same rules as Lab 06)

const getStatus = (cgpa) =>
  cgpa >= 3.0 ? "Excellent" :
  cgpa >= 2.5 ? "Good" :
  cgpa >= 2.0 ? "Satisfactory" :
  "Academic Warning";

module.exports = { getStatus };
